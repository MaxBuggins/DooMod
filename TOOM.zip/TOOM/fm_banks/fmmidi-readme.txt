A bank, created from hardcoded instruments, extracted from "fmmidi" project

http://unhaut.x10host.com/fmmidi/

It's license:
This program is released under the "three clauses" BSD license

